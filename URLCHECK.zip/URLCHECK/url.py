import urllib.parse
import os

def print_logo():
    logo = """                 

██    ██ ██████  ██           ██████ ██    ██ ████████ ████████ ███████ ██████  
██    ██ ██   ██ ██          ██      ██    ██    ██       ██    ██      ██   ██ 
██    ██ ██████  ██          ██      ██    ██    ██       ██    █████   ██████  
██    ██ ██   ██ ██          ██      ██    ██    ██       ██    ██      ██   ██ 
 ██████  ██   ██ ███████      ██████  ██████     ██       ██    ███████ ██   ██ 
                                                                                      
Created By Rey (REXYZ)        URL CUTTER & REMOVE DUPLICATE <  Version 1.0.0  >                                                                                        
          """
    print(logo)

def print_menu():
    menu = """
    MENU:
    1. Pilih / Masukkan File (.txt)
    2. Keluar
    """
    print(menu)

def process_urls(file_path):
    with open(file_path, 'r') as infile:
        urls = infile.readlines()
    processed_urls = set()
    for url in urls:
        url = url.strip()
        if url:
            parsed_url = urllib.parse.urlparse(url)
            trimmed_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"
            processed_urls.add(trimmed_url)
    return list(processed_urls)

if __name__ == "__main__":
    while True:
        print_logo()
        print_menu()
        choice = input("Enter your choice: ").strip()

        if choice == '1':
            file_path = input("Enter the path to the .txt file: ").strip()
            if not file_path.endswith('.txt'):
                print("Tolong masukkan file dengan ekstensi .txt !!!")
                continue

            output_file = input("Enter the desired name for the output file (e.g., output.txt): ").strip()
            if not output_file.endswith('.txt'):
                print("Tolong masukkan nama file output dengan ekstensi .txt !!!")
                continue

            if not os.path.isfile(file_path):
                print("Tolong periksa kembali file anda !!!")
                continue
            
            try:
                processed_urls = process_urls(file_path)
                
                # Print to console
                print("\nTrimmed URLs:")
                for url in processed_urls:
                    print(url)
                
                # Save to the specified output file
                with open(output_file, 'w') as outfile:
                    for url in processed_urls:
                        outfile.write(url + "\n")
                
                print(f"Output saved to '{output_file}'")
            except Exception as e:
                print(f"An error occurred: {e}")
        
        elif choice == '2':
            print("Exiting...")
            break
        
        else:
            print("Invalid choice. Please enter 1 or 2.")
